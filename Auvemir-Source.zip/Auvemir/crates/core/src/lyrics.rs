#[derive(Debug, Clone, PartialEq)]
pub struct Line {
    pub ms: u64,
    pub text: String,
}
pub fn parse_lrc(text: &str) -> Vec<Line> {
    let mut result = Vec::new();
    for raw in text.lines() {
        let mut line = raw;
        let mut times = Vec::new();
        while let Some(rest) = line.strip_prefix('[') {
            let Some((stamp, remaining)) = rest.split_once(']') else {
                break;
            };
            if let Some((min, sec)) = stamp.split_once(':')
                && let (Ok(m), Ok(s)) = (min.parse::<u64>(), sec.parse::<f64>())
                && s.is_finite()
                && (0.0..60.0).contains(&s)
            {
                times.push(
                    m.saturating_mul(60_000)
                        .saturating_add((s * 1000.0).round() as u64),
                );
            }
            line = remaining;
        }
        for ms in times {
            result.push(Line {
                ms,
                text: line.to_owned(),
            });
        }
    }
    result.sort_by_key(|l| l.ms);
    result
}
pub fn active_line(lines: &[Line], ms: u64) -> Option<usize> {
    lines.partition_point(|l| l.ms <= ms).checked_sub(1)
}
