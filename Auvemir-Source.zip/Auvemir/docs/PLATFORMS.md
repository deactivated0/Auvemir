# Platform and package status

| Platform | Current evidence | Remaining |
|---|---|---|
| Linux x86_64 | Release compiled; actual Slint desktop/phone renders, native decoder fixtures, synthetic ALSA output and MPRIS protocol checks passed | Physical speaker/microphone, real desktop portal/credentials/media keys, installation and hardware tests |
| Linux ARM64 | Native Ubuntu ARM64 release workflow prepared | Run workflow and verify devices/packages |
| Windows x86_64 | Previous checkpoint compiled with MinGW and packaged as portable ZIP and per-user NSIS; MSVC workflow and SMTC source included | Rebuild current source; run MSVC workflow, WASAPI/SMTC/dialog/microphone verification and signing |
| Windows ARM64 | Not built | Native libclang/toolchain support, build and device validation |
| macOS Intel/ARM64 | Native jobs, Now Playing adapter and app/DMG scripts prepared | Run workflow, Core Audio/Keychain/microphone verification, signing/notarization |
| Android | NativeActivity/NDK entry point, SAF import, encrypted KeyStore credentials, foreground media/microphone service, focus, MediaSession and paged car browser; Java and DEX compilation passed | New source passes ARM64 compile/Clippy and Java/DEX checks, including a persistent worker and cold-start car engine. Current APK rebuilds and emulator/physical lifecycle/audio tests remain pending |
| iOS | Rust static library entry point, Swift host, Files import, Keychain, AVAudioSession, Now Playing, background audio and AirPlay source; xtool/Apple build scripts | Apple SDK compile, signing and physical device checks; CarPlay approval and runtime checks (source and entitlement template are included) |

A narrow desktop screenshot is not an Android APK or an iOS build. Mobile native hosts are now source implementations; no device validation is claimed.

Linux packages target glibc 2.39+ because of the native build host. Portable tarball, DEB, RPM, Arch and AppImage builders are provided. Package contents/extracted execution can be checked here; installation and distribution coverage require separate environments. The AppImage bundles selected replaceable native libraries, not glibc, drivers or session services. Flatpak is pending.

GitHub builds create draft desktop release assets plus a vendored corresponding-source archive. A successful build is not a device test. There are no fabricated Windows/macOS binaries, certificates or Apple provisioning profiles.
