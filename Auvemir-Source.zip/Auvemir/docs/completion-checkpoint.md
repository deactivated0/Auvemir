# Checkpoint 17

The full product brief remains unfinished. Source checkpoint 16 compiled both Android APKs, but native desktop validation stopped on a test-only Clippy warning. Android API 28 and 35 runtime checks failed because the test could issue its first import before Application.onCreate initialized the engine. The test now connects the real browser service first; this ordering is grounded in Android ActivityThread. The corrected tests still require a fresh run.

No public release has been made. Last fully packaged Linux and Windows builds are checkpoint 15. See FEATURES.md for outstanding product work.
